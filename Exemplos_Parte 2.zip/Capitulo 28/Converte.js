<!DOCTYPE html>
<html>
    <meta charset="UTF-8">
    <button onclick="exibe()">Clique Aqui</button>   
</html>

 <script>
   function fileTimeToDate(hexFileTime) {
    // Converte hexadecimal para número inteiro
    let fileTime = BigInt("0x" + hexFileTime);
    
    // FILETIME começa em 1º de janeiro de 1601 e conta em intervalos de 100 nanossegundos
    let epochStart = new Date(Date.UTC(1601, 0, 1));
    
    // Converte FILETIME para milissegundos
    let milliseconds = Number(fileTime / BigInt(10)) / 1000;
    
    // Adiciona ao início da era FILETIME
    let finalDate = new Date(epochStart.getTime() + milliseconds);
    
    return finalDate.toUTCString(); // Retorna a data em formato legível
}

// Exemplo de uso:
let hexTimestamp = "C4928E51868BC401"; 
console.log("Data e hora do desligamento: ", fileTimeToDate(hexTimestamp));
 </script>